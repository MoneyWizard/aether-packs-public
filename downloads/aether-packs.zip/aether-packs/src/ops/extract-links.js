(function(){
  var as=Array.prototype.slice.call(document.querySelectorAll('a[href]'));
  var host=location.hostname.replace(/^www\./,'');
  var lines=as.map(function(a){
    try{
      var u=new URL(a.href,location.href);
      var ext=u.hostname.replace(/^www\./,'')!==host?'EXT':'INT';
      return ext+'\t'+u.href+'\t'+((a.textContent||'').trim().replace(/\s+/g,' ').slice(0,80));
    }catch(e){return 'BAD\t'+a.getAttribute('href');}
  });
  var blob=new Blob(['kind\thref\tanchor\n'+lines.join('\n')],{type:'text/csv'});
  var url=URL.createObjectURL(blob);
  var a=document.createElement('a');a.href=url;a.download=(location.hostname||'links')+'-links.csv';a.click();
  URL.revokeObjectURL(url);
})();
