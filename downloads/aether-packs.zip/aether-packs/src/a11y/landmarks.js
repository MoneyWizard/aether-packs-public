(function(){
  var CLS='aether-lm';
  if(document.querySelector('.'+CLS)){document.querySelectorAll('.'+CLS).forEach(function(n){n.remove();});document.querySelectorAll('[data-aether-lm]').forEach(function(el){el.style.outline='';el.removeAttribute('data-aether-lm');});var p=document.getElementById('aether-lm-panel');if(p)p.remove();return;}
  var sel='header,nav,main,footer,aside,section,form,[role="banner"],[role="navigation"],[role="main"],[role="contentinfo"],[role="complementary"],[role="search"],[role="region"],[role="form"]';
  var els=Array.prototype.slice.call(document.querySelectorAll(sel));
  var colors={banner:'#f97316',navigation:'#38bdf8',main:'#22c55e',contentinfo:'#a78bfa',complementary:'#f472b6',search:'#eab308',region:'#94a3b8',form:'#fb7185'};
  function roleOf(el){
    var r=(el.getAttribute('role')||'').toLowerCase();
    if(r)return r;
    var t=el.tagName.toLowerCase();
    return {header:'banner',nav:'navigation',main:'main',footer:'contentinfo',aside:'complementary',form:'form',section:'region'}[t]||t;
  }
  var counts={};
  els.forEach(function(el){
    var r=roleOf(el);counts[r]=(counts[r]||0)+1;
    var label=el.getAttribute('aria-label')||el.getAttribute('aria-labelledby')||'';
    el.setAttribute('data-aether-lm','1');
    el.style.outline='3px dashed '+(colors[r]||'#fff');
    var b=document.createElement('div');b.className=CLS;
    b.textContent=r+(label?' “'+String(label).slice(0,40)+'”':'');
    b.style.cssText='position:absolute;z-index:2147483646;background:'+(colors[r]||'#111')+';color:#111;font:700 10px/1.2 ui-sans-serif,system-ui;padding:2px 5px;';
    if(getComputedStyle(el).position==='static')el.style.position='relative';
    el.insertBefore(b,el.firstChild);
  });
  var mains=(counts.main||0);
  var panel=document.createElement('div');panel.id='aether-lm-panel';
  panel.style.cssText='all:initial;position:fixed;top:12px;left:12px;z-index:2147483647;background:#0b1220;color:#e5e7eb;font:12px ui-sans-serif,system-ui;padding:12px;border-radius:10px;max-width:280px;border:1px solid #1f2937;';
  panel.innerHTML='<strong style="color:#86efac;">Landmarks</strong><div style="margin-top:6px;">'+Object.keys(counts).map(function(k){return k+': '+counts[k];}).join('<br>')+'</div><div style="color:#9ca3af;margin-top:8px;">main regions: '+mains+(mains===1?' ✓':' ⚠ should be 1')+'</div>';
  document.body.appendChild(panel);
})();
