(function(){
  var ID='aether-gray';
  var s=document.getElementById(ID);
  if(s){s.remove();document.documentElement.classList.remove('aether-gray');return;}
  s=document.createElement('style');s.id=ID;
  s.textContent='html.aether-gray{filter:grayscale(1) !important;}';
  document.head.appendChild(s);
  document.documentElement.classList.add('aether-gray');
})();
