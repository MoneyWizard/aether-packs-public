(function(){
  var n=0;
  document.querySelectorAll('input[type=password]').forEach(function(el){el.type='text';el.style.outline='2px solid #facc15';n++;});
  alert(n?('Revealed '+n+' password field(s). Refresh to mask again.'):'No password fields on this page.');
})();
