(function(){
  var ID='aether-cwv';
  if(document.getElementById(ID)){document.getElementById(ID).remove();return;}
  var box=document.createElement('div');box.id=ID;
  box.style.cssText='all:initial;position:fixed;bottom:12px;left:12px;z-index:2147483647;background:#0b1220;color:#e5e7eb;font:12px/1.45 ui-monospace,ui-sans-serif,system-ui;padding:10px 12px;border-radius:10px;border:1px solid #1f2937;min-width:220px;';
  box.textContent='CWV · collecting… interact for INP';
  document.body.appendChild(box);
  var state={lcp:null,cls:0,inp:null};
  function rate(m,g,n){return m==null?'#9ca3af':m<=g?'#22c55e':m<=n?'#eab308':'#ef4444';}
  function paint(){
    box.innerHTML='<b style="color:#93c5fd;font-family:ui-sans-serif;">Core Web Vitals</b>'+
      '<div>LCP <span style="color:'+rate(state.lcp,2500,4000)+'">'+(state.lcp==null?'…':Math.round(state.lcp)+' ms')+'</span></div>'+
      '<div>CLS <span style="color:'+rate(state.cls,0.1,0.25)+'">'+state.cls.toFixed(3)+'</span></div>'+
      '<div>INP <span style="color:'+rate(state.inp,200,500)+'">'+(state.inp==null?'interact…':Math.round(state.inp)+' ms')+'</span></div>'+
      '<div style="color:#6b7280;margin-top:4px;">good / needs improvement / poor</div>';
  }
  try{
    new PerformanceObserver(function(list){list.getEntries().forEach(function(e){state.lcp=e.startTime;});paint();}).observe({type:'largest-contentful-paint',buffered:true});
    new PerformanceObserver(function(list){list.getEntries().forEach(function(e){if(!e.hadRecentInput)state.cls+=e.value;});paint();}).observe({type:'layout-shift',buffered:true});
    new PerformanceObserver(function(list){list.getEntries().forEach(function(e){state.inp=e.duration;});paint();}).observe({type:'event',buffered:true,durationThreshold:16});
  }catch(err){box.textContent='CWV observers unsupported in this browser';}
  paint();
})();
