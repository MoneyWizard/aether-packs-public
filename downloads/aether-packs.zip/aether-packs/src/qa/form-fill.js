(function(){
  function set(el,val){
    var proto=el.constructor&&el.constructor.prototype;
    var desc=proto&&Object.getOwnPropertyDescriptor(proto,'value');
    if(desc&&desc.set)desc.set.call(el,val);else el.value=val;
    el.dispatchEvent(new Event('input',{bubbles:true}));
    el.dispatchEvent(new Event('change',{bubbles:true}));
    if(window.KeyboardEvent)el.dispatchEvent(new Event('blur',{bubbles:true}));
  }
  var uid=Math.random().toString(36).slice(2,6);
  var map={
    email:'qa+'+uid+'@example.com',
    mail:'qa+'+uid+'@example.com',
    name:'Ada Lovelace',
    first:'Ada',fname:'Ada',firstname:'Ada',
    last:'Lovelace',lname:'Lovelace',lastname:'Lovelace',
    fullname:'Ada Lovelace',
    phone:'4155550199',tel:'4155550199',mobile:'4155550199',
    zip:'94107',postcode:'94107',postal:'94107',
    city:'San Francisco',state:'CA',country:'United States',
    address:'1 Market St',street:'1 Market St',
    company:'Aether QA',organization:'Aether QA',
    url:'https://example.com',website:'https://example.com',
    password:'TestPass!23456',pass:'TestPass!23456',
    search:'test query',q:'test query',
    card:'4242424242424242',cc:'4242424242424242',
    cvv:'123',cvc:'123',
    date:'2026-09-01'
  };
  var filled=0;
  Array.prototype.slice.call(document.querySelectorAll('input,textarea,select')).forEach(function(el){
    if(el.disabled||el.readOnly||el.type==='hidden'||el.type==='file'||el.type==='submit'||el.type==='button'||el.type==='image')return;
    var key=((el.name||'')+' '+(el.id||'')+' '+(el.placeholder||'')+' '+(el.getAttribute('autocomplete')||'')+' '+(el.type||'')).toLowerCase();
    var val=null;
    if(el.type==='email'||/e-?mail/.test(key))val=map.email;
    else if(el.type==='tel'||/phone|mobile|tel/.test(key))val=map.phone;
    else if(el.type==='url'||/website|url/.test(key))val=map.url;
    else if(el.type==='password')val=map.password;
    else if(el.type==='number')val='42';
    else if(el.type==='date')val=map.date;
    else if(el.type==='checkbox'){el.checked=true;el.dispatchEvent(new Event('change',{bubbles:true}));filled++;return;}
    else if(el.type==='radio'){if(!document.querySelector('input[type=radio][name="'+el.name+'"]:checked')){el.checked=true;el.dispatchEvent(new Event('change',{bubbles:true}));filled++;}return;}
    else if(el.tagName==='SELECT'){if(el.options.length){el.selectedIndex=Math.min(1,el.options.length-1);el.dispatchEvent(new Event('change',{bubbles:true}));filled++;}return;}
    else {
      for(var k in map){if(key.indexOf(k)!==-1){val=map[k];break;}}
      if(!val)val=el.tagName==='TEXTAREA'?'QA note '+uid+' — ignore this automated fill.':'Test '+uid;
    }
    set(el,val);filled++;
  });
  var n=document.createElement('div');
  n.style.cssText='all:initial;position:fixed;bottom:16px;left:50%;transform:translateX(-50%);z-index:2147483647;background:#052e16;color:#86efac;font:13px ui-sans-serif,system-ui;padding:8px 14px;border-radius:999px;border:1px solid #166534;';
  n.textContent='Filled '+filled+' fields (React/Vue-safe events)';
  document.body.appendChild(n);setTimeout(function(){n.remove();},2200);
})();
