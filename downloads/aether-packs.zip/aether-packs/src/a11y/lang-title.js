(function(){
  var htmlLang=document.documentElement.getAttribute('lang')||'(missing)';
  var title=document.title||'(missing)';
  var xml=document.documentElement.getAttribute('xml:lang');
  var mismatches=[];
  Array.prototype.slice.call(document.querySelectorAll('[lang]')).forEach(function(el){
    mismatches.push((el.tagName.toLowerCase())+' lang='+el.getAttribute('lang')+' “'+(el.textContent||'').trim().slice(0,40)+'”');
  });
  var skip=document.querySelector('a[href^="#"],.skip,.skip-link,[href="#main"],[href="#content"]');
  alert('Aether · Page identity\n\n<html lang> = '+htmlLang+'\ntitle = '+title+'\nxml:lang = '+(xml||'(none)')+'\nSkip link found: '+(skip?'yes ('+(skip.getAttribute('href')||skip.className)+')':'NO')+'\n\nElements with lang attr: '+mismatches.length+'\n'+mismatches.slice(0,12).join('\n'));
})();
