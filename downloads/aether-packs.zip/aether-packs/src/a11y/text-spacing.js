(function(){
  var ID='aether-space';
  var s=document.getElementById(ID);
  var n=document.getElementById(ID+'n');
  if(s||n){
    if(s)s.remove();
    if(n)n.remove();
    document.documentElement.classList.remove('aether-space');
    return;
  }
  s=document.createElement('style');s.id=ID;
  s.textContent='html.aether-space,html.aether-space *{line-height:1.5 !important;letter-spacing:.12em !important;word-spacing:.16em !important;}html.aether-space p,html.aether-space li,html.aether-space dd,html.aether-space figcaption{margin-bottom:2em !important;}';
  document.head.appendChild(s);
  document.documentElement.classList.add('aether-space');
  n=document.createElement('div');n.id=ID+'n';
  n.style.cssText='all:initial;position:fixed;top:8px;left:50%;transform:translateX(-50%);z-index:2147483647;background:#0b1220;color:#86efac;font:12px ui-sans-serif,system-ui;padding:8px 12px;border-radius:999px;';
  n.textContent='WCAG 1.4.12 text spacing ON — content must not clip. Click tool again to reset.';
  document.body.appendChild(n);
})();
