(function(){
  var root=document.querySelector('article,main,[role="main"]')||document.body;
  var text=(root.innerText||'').replace(/\s+/g,' ').trim();
  var words=text?text.split(' ').length:0;
  var chars=text.length;
  var mins=Math.max(1,Math.round(words/230));
  var links=root.querySelectorAll('a[href]').length;
  var imgs=root.querySelectorAll('img').length;
  alert('Aether · Content stats\n\nScope: '+(root===document.body?'<body>':root.tagName.toLowerCase())+'\nWords: '+words+'\nCharacters: '+chars+'\nEst. read time: '+mins+' min (@230 wpm)\nLinks in scope: '+links+'\nImages in scope: '+imgs);
})();
