(function(){
  var CLS='aether-h-badge';
  var existing=document.querySelectorAll('.'+CLS);
  if(existing.length){existing.forEach(function(n){n.remove();});document.querySelectorAll('[data-aether-h]').forEach(function(el){el.style.outline='';el.removeAttribute('data-aether-h');});var p=document.getElementById('aether-h-panel');if(p)p.remove();return;}
  var hs=Array.prototype.slice.call(document.querySelectorAll('h1,h2,h3,h4,h5,h6,[role="heading"]'));
  var colors={H1:'#ef4444',H2:'#f97316',H3:'#eab308',H4:'#22c55e',H5:'#06b6d4',H6:'#8b5cf6'};
  var outline=[],last=0,skips=0,empty=0;
  hs.forEach(function(el){
    var lvl=parseInt((el.tagName[1])||el.getAttribute('aria-level')||'0',10);
    if(!lvl)return;
    if(last&&lvl>last+1)skips++;
    last=last?last:lvl===1?1:lvl;
    last=lvl;
    var text=(el.textContent||'').trim();
    if(!text)empty++;
    el.setAttribute('data-aether-h','1');
    el.style.outline='2px solid '+(colors['H'+lvl]||'#fff');
    var b=document.createElement('span');
    b.className=CLS;
    b.textContent='H'+lvl;
    b.style.cssText='position:absolute;z-index:2147483646;background:'+(colors['H'+lvl]||'#111')+';color:#111;font:700 10px/1 ui-sans-serif,system-ui;padding:2px 4px;border-radius:3px;transform:translateY(-110%);pointer-events:none;';
    if(getComputedStyle(el).position==='static')el.style.position='relative';
    el.insertBefore(b,el.firstChild);
    outline.push('H'+lvl+'  '+text.slice(0,90));
  });
  var h1=hs.filter(function(e){return e.tagName==='H1';}).length;
  var panel=document.createElement('div');
  panel.id='aether-h-panel';
  panel.style.cssText='all:initial;position:fixed;top:12px;left:12px;z-index:2147483647;max-width:360px;max-height:80vh;overflow:auto;background:#0b1220;color:#e5e7eb;font:12px/1.4 ui-sans-serif,system-ui;padding:12px;border-radius:10px;border:1px solid #1f2937;';
  panel.innerHTML='<strong style="color:#93c5fd;">Heading map</strong> · '+hs.length+' tags · H1s: '+h1+' · skips: '+skips+' · empty: '+empty+'<pre style="white-space:pre-wrap;margin:8px 0 0;color:#d1d5db;">'+outline.map(function(s){return s.replace(/[&<>]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;'}[c];});}).join('\n')+'</pre><div style="color:#6b7280;margin-top:6px;">Click bookmarklet again to clear.</div>';
  document.body.appendChild(panel);
})();
