(function(){
  try{
    var u=new URL(location.href);
    ['utm_source','utm_medium','utm_campaign','utm_term','utm_content','utm_id','gclid','gbraid','wbraid','fbclid','msclkid','mc_cid','mc_eid','igshid','si','ref','ref_src'].forEach(function(k){u.searchParams.delete(k);});
    history.replaceState(null,'',u.pathname+u.search+u.hash);
    if(navigator.clipboard)navigator.clipboard.writeText(u.toString());
    toast('Tracking params stripped · clean URL copied');
  }catch(e){alert(e);}
  function toast(t){var n=document.createElement('div');n.style.cssText='all:initial;position:fixed;bottom:16px;left:50%;transform:translateX(-50%);z-index:2147483647;background:#0b1220;color:#93c5fd;font:13px ui-sans-serif,system-ui;padding:8px 14px;border-radius:999px;';n.textContent=t;document.body.appendChild(n);setTimeout(function(){n.remove();},1800);}
})();
