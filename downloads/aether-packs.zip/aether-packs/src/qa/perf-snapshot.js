(function(){
  var t=performance.timing||{};
  var nav=performance.getEntriesByType&&performance.getEntriesByType('navigation')[0];
  function ms(a,b){return (a&&b&&b>a)?(b-a)+' ms':'n/a';}
  var res=(performance.getEntriesByType&&performance.getEntriesByType('resource'))||[];
  var by={};
  res.forEach(function(r){var k=(r.initiatorType||'other');by[k]=(by[k]||0)+1;});
  var paint=performance.getEntriesByType&&performance.getEntriesByType('paint')||[];
  var fp=paint.filter(function(p){return p.name==='first-contentful-paint';})[0];
  var msg='Aether · Performance snapshot\n\n'+
    'Nav type: '+(nav?nav.type:(performance.navigation&&performance.navigation.type))+'\n'+
    'TTFB: '+(nav?Math.round(nav.responseStart)+' ms':ms(t.requestStart,t.responseStart))+'\n'+
    'DOMContentLoaded: '+(nav?Math.round(nav.domContentLoadedEventEnd)+' ms':ms(t.navigationStart,t.domContentLoadedEventEnd))+'\n'+
    'Load: '+(nav?Math.round(nav.loadEventEnd)+' ms':ms(t.navigationStart,t.loadEventEnd))+'\n'+
    'FCP: '+(fp?Math.round(fp.startTime)+' ms':'n/a')+'\n'+
    'Transfer size: '+(nav&&nav.transferSize?Math.round(nav.transferSize/1024)+' KB':'n/a')+'\n'+
    'Resources: '+res.length+'  '+JSON.stringify(by)+'\n\n'+
    'Tip: pair with Core Web Vitals overlay for LCP/CLS/INP.';
  alert(msg);
})();
