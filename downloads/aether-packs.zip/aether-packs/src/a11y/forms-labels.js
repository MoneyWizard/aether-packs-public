(function(){
  var ID='aether-forms';var old=document.getElementById(ID);if(old){document.querySelectorAll('[data-aether-f]').forEach(function(el){el.style.outline='';el.removeAttribute('data-aether-f');});old.remove();return;}
  var fields=Array.prototype.slice.call(document.querySelectorAll('input:not([type=hidden]):not([type=submit]):not([type=button]):not([type=image]):not([type=reset]),select,textarea'));
  var bad=[];
  fields.forEach(function(el){
    var id=el.id;
    var labeled=!!(id&&document.querySelector('label[for="'+CSS.escape(id)+'"]'))||!!el.closest('label')||!!el.getAttribute('aria-label')||!!el.getAttribute('aria-labelledby')||!!el.getAttribute('title');
    el.setAttribute('data-aether-f','1');
    el.style.outline=labeled?'2px solid #22c55e':'3px solid #ef4444';
    if(!labeled)bad.push({tag:el.tagName.toLowerCase(),type:el.type||'',name:el.name||el.id||'(no name)'});
  });
  var box=document.createElement('div');box.id=ID;
  box.style.cssText='all:initial;position:fixed;top:12px;right:12px;z-index:2147483647;width:340px;max-height:80vh;overflow:auto;background:#0b1220;color:#e5e7eb;font:12px/1.4 ui-sans-serif,system-ui;padding:12px;border-radius:10px;border:1px solid #1f2937;';
  box.innerHTML='<strong style="color:#86efac;">Form labels</strong><div style="margin:6px 0;color:#9ca3af;">'+fields.length+' fields · '+bad.length+' unlabeled (red)</div>'+
    bad.map(function(b){return '<div style="border-top:1px solid #1f2937;padding:4px 0;">'+b.tag+(b.type?'[type='+b.type+']':'')+' · '+esc(b.name)+'</div>';}).join('')+
    '<div style="color:#6b7280;margin-top:8px;">Green = has label / aria-label / title. Click again to clear.</div>';
  function esc(s){return String(s).replace(/[&<>]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;'}[c];});}
  document.body.appendChild(box);
})();
