#!/usr/bin/env python3
"""Compile Aether Pack bookmarklets into a drag-to-install gallery."""
from __future__ import annotations

import json
import urllib.parse
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CATALOG = json.loads((ROOT / "catalog.json").read_text())


def minify_lite(src: str) -> str:
    lines = []
    for raw in src.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("//"):
            continue
        lines.append(line)
    code = "\n".join(lines)
    return code


def to_bookmarklet(src: str) -> str:
    code = minify_lite(src)
    if not code.startswith("(") and not code.startswith("!"):
        code = f"(function(){{{code}}})()"
    # wrap if file already is IIFE
    href = "javascript:" + urllib.parse.quote(code, safe="()[],;:=!/*+")
    return href


def tool_card(tool: dict, accent: str) -> str:
    src = (ROOT / tool["file"]).read_text()
    href = to_bookmarklet(src)
    name = tool["name"]
    desc = tool["desc"]
    size = len(href)
    return f"""
    <article class="card">
      <a class="drag" href="{href}" title="Drag to bookmarks bar">{name}</a>
      <p>{desc}</p>
      <div class="meta">
        <button class="copy" data-code="{href}">Copy javascript: URL</button>
        <span>{size:,} chars</span>
      </div>
    </article>
    """


def pack_section(pack: dict) -> str:
    cards = "\n".join(tool_card(t, pack["accent"]) for t in pack["tools"])
    return f"""
    <section class="pack" id="pack-{pack['id']}" style="--accent:{pack['accent']}">
      <header>
        <p class="kicker">{pack['id'].upper()} PACK</p>
        <h2>{pack['name']}</h2>
        <p class="blurb">{pack['blurb']}</p>
      </header>
      <div class="grid">{cards}</div>
    </section>
    """


CSS = """
:root { --bg:#070b14; --ink:#e5e7eb; --muted:#9ca3af; --line:#1f2937; --card:#0d1424; }
* { box-sizing:border-box; }
html,body { margin:0; background:var(--bg); color:var(--ink); font:16px/1.5 ui-sans-serif,system-ui,sans-serif; }
a { color:inherit; }
.wrap { max-width:1120px; margin:0 auto; padding:48px 20px 80px; }
.hero { padding-bottom:36px; border-bottom:1px solid var(--line); }
.hero h1 { font-size:clamp(32px,5vw,56px); letter-spacing:-.03em; margin:0 0 8px; }
.hero .tag { color:#93c5fd; font-weight:600; letter-spacing:.16em; font-size:12px; }
.hero p.lead { max-width:640px; color:var(--muted); font-size:18px; }
.nav { display:flex; flex-wrap:wrap; gap:8px; margin-top:20px; }
.nav a { border:1px solid var(--line); padding:6px 12px; border-radius:999px; text-decoration:none; font-size:13px; color:#93c5fd; }
.how { margin:28px 0; padding:16px 18px; background:#0b1220; border:1px solid var(--line); border-radius:12px; color:var(--muted); font-size:14px; }
.pack { margin:48px 0; }
.kicker { color:var(--accent); letter-spacing:.14em; font-size:11px; font-weight:700; margin:0; }
.pack h2 { margin:4px 0 8px; font-size:28px; letter-spacing:-.02em; }
.blurb { color:var(--muted); max-width:60ch; }
.grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(260px,1fr)); gap:14px; margin-top:18px; }
.card { background:var(--card); border:1px solid var(--line); border-radius:14px; padding:16px; display:flex; flex-direction:column; gap:8px; }
.drag { display:inline-block; align-self:flex-start; background:var(--accent); color:#081018; font-weight:700; text-decoration:none; padding:8px 12px; border-radius:8px; }
.drag:hover { filter:brightness(1.08); }
.card p { margin:0; color:var(--muted); font-size:14px; flex:1; }
.meta { display:flex; justify-content:space-between; align-items:center; gap:8px; font-size:11px; color:#6b7280; }
.copy { background:#1f2937; color:#e5e7eb; border:0; border-radius:6px; padding:5px 8px; cursor:pointer; font:11px ui-sans-serif,system-ui; }
.legal { margin-top:64px; color:#6b7280; font-size:13px; border-top:1px solid var(--line); padding-top:20px; }
code { font-family:ui-monospace,monospace; font-size:12px; }
"""

JS = """
document.querySelectorAll('.copy').forEach(function(btn){
  btn.addEventListener('click', async function(){
    const code = btn.getAttribute('data-code');
    try { await navigator.clipboard.writeText(code); btn.textContent = 'Copied'; setTimeout(()=>btn.textContent='Copy javascript: URL', 1400); }
    catch(e){ prompt('Copy bookmarklet', code); }
  });
});
"""


def render() -> str:
    sections = "\n".join(pack_section(p) for p in CATALOG["packs"])
    nav = "".join(f'<a href="#pack-{p["id"]}">{p["name"]}</a>' for p in CATALOG["packs"])
    n_tools = sum(len(p["tools"]) for p in CATALOG["packs"])
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>{CATALOG['product']} — Bookmarklet Bundles</title>
<style>{CSS}</style>
</head>
<body>
<main class="wrap">
  <header class="hero">
    <div class="tag">PREMIUM BONUS TOOLKIT · v{CATALOG['version']}</div>
    <h1>{CATALOG['product']}</h1>
    <p class="lead">{CATALOG['tagline']} {n_tools} specialized bookmarklets across SEO, accessibility, QA, and daily ops. No extension store. No telemetry. Runs only when clicked.</p>
    <nav class="nav">{nav}</nav>
  </header>
  <div class="how">
    <strong style="color:#e5e7eb;">Install.</strong> Show the bookmarks bar (Ctrl/Cmd+Shift+B). Drag a colored button onto the bar.
    On mobile: Copy javascript: URL → Add Bookmark → paste into the URL field.
    Click the same tool again on a page to dismiss overlays.
    <br/><strong style="color:#e5e7eb;">Trust model.</strong> Source lives next to this page in <code>src/</code>. Bookmarklets inherit the page origin — do not run untrusted bookmarklets on authenticated apps you do not control.
  </div>
  {sections}
  <footer class="legal">
    {CATALOG['product']} is designed as a member / SaaS bonus: host this folder behind your paywall, or white-label via WHITE-LABEL.md.
    Tools perform in-page DOM reads except Index Operators (opens third-party tools in a new tab) and Export Links (local CSV download).
  </footer>
</main>
<script>{JS}</script>
</body>
</html>
"""


def main() -> None:
    html = render()
    out = ROOT / "index.html"
    out.write_text(html)
    print(f"Wrote {out} ({len(html):,} bytes)")


if __name__ == "__main__":
    main()
