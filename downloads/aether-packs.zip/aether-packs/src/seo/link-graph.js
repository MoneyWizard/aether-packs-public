(function(){
  var ID='aether-links';
  var old=document.getElementById(ID);
  if(old){old.remove();document.querySelectorAll('[data-aether-l]').forEach(function(a){a.style.outline='';a.removeAttribute('data-aether-l');});return;}
  var as=Array.prototype.slice.call(document.querySelectorAll('a[href]'));
  var host=location.hostname.replace(/^www\./,'');
  var rows=[],int=0,ext=0,nof=0,spon=0,ugc=0,hash=0,empty=0,js=0;
  as.forEach(function(a){
    var href=a.getAttribute('href')||'';
    var rel=(a.rel||'').toLowerCase();
    var nf=/\bnofollow\b/.test(rel),sp=/\bsponsored\b/.test(rel),ug=/\bugc\b/.test(rel);
    var kind='int';
    if(!href||href==='#'){kind='empty';empty++;}
    else if(/^javascript:/i.test(href)){kind='js';js++;}
    else if(href.charAt(0)==='#'){kind='hash';hash++;}
    else{
      try{
        var u=new URL(a.href,location.href);
        if(u.hostname.replace(/^www\./,'')!==host){kind='ext';ext++;} else int++;
      }catch(e){kind='int';int++;}
    }
    if(nf)nof++; if(sp)spon++; if(ug)ugc++;
    var col=kind==='ext'?'#38bdf8':kind==='empty'?'#ef4444':nf?'#f97316':'#22c55e';
    a.style.outline='2px solid '+col;
    a.setAttribute('data-aether-l','1');
    rows.push({kind:kind,rel:rel||'follow',text:(a.textContent||'').trim().slice(0,60)||'(no text)',href:href.slice(0,120)});
  });
  var box=document.createElement('div');
  box.id=ID;
  box.style.cssText='all:initial;position:fixed;bottom:12px;right:12px;z-index:2147483647;width:420px;max-height:50vh;overflow:auto;background:#0b1220;color:#e5e7eb;font:12px/1.4 ui-sans-serif,system-ui;padding:12px;border-radius:10px;border:1px solid #1f2937;';
  box.innerHTML='<strong style="color:#93c5fd;">Link graph</strong> · '+as.length+' anchors<br>internal '+int+' · external '+ext+' · hash '+hash+' · empty '+empty+' · js '+js+'<br>nofollow '+nof+' · sponsored '+spon+' · ugc '+ugc+
    '<div style="margin-top:8px;color:#9ca3af;">Green=internal follow · Blue=external · Orange=nofollow · Red=empty</div>';
  document.body.appendChild(box);
})();
