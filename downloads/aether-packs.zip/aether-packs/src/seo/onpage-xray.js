(function(){
  var ID='aether-seo-xray';
  var old=document.getElementById(ID);
  if(old){old.remove();return;}
  function t(sel){var e=document.querySelector(sel);return e?(e.content||e.getAttribute('content')||e.href||e.textContent||'').trim():'';}
  function all(sel){return Array.prototype.slice.call(document.querySelectorAll(sel));}
  var title=document.title||'';
  var desc=t('meta[name="description"]');
  var robots=t('meta[name="robots"]')||'(none)';
  var canon=t('link[rel="canonical"]')||'(none)';
  var hreflang=all('link[rel="alternate"][hreflang]').map(function(l){return (l.hreflang||'')+' → '+(l.href||'');});
  var ogt=t('meta[property="og:title"]');
  var ogd=t('meta[property="og:description"]');
  var ogi=t('meta[property="og:image"]');
  var tw=t('meta[name="twitter:card"]');
  var jsonld=all('script[type="application/ld+json"]').length;
  var h1s=all('h1').map(function(h){return h.textContent.trim().slice(0,80);});
  var imgs=all('img');
  var noalt=imgs.filter(function(i){return !i.getAttribute('alt')&&i.getAttribute('alt')!=='';}).length;
  var emptyalt=imgs.filter(function(i){return i.getAttribute('alt')==='';}).length;
  var links=all('a[href]');
  var here=location.hostname.replace(/^www\./,'');
  var ext=links.filter(function(a){try{return new URL(a.href,location.href).hostname.replace(/^www\./,'')!==here;}catch(e){return false;}}).length;
  var nof=links.filter(function(a){return /\bnofollow\b/i.test(a.rel||'');}).length;
  var selfCanon=canon!=='(none)'&&canon.split('#')[0].replace(/\/$/,'')===location.href.split('#')[0].replace(/\/$/,'');
  var titleLen=title.length;
  var descLen=desc.length;
  function pill(ok,warn){return ok?'#16a34a':(warn?'#ca8a04':'#dc2626');}
  var html='<div id="'+ID+'" style="all:initial;position:fixed;top:12px;right:12px;z-index:2147483647;width:380px;max-height:92vh;overflow:auto;background:#0b1220;color:#e5e7eb;font:13px/1.45 ui-sans-serif,system-ui,sans-serif;border:1px solid #1f2937;border-radius:12px;box-shadow:0 20px 50px rgba(0,0,0,.45);padding:14px 16px;">'+
    '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;"><strong style="font-size:14px;letter-spacing:.02em;color:#93c5fd;">Aether · On-Page X-Ray</strong><button id="'+ID+'-x" style="background:#1f2937;color:#fff;border:0;border-radius:6px;padding:4px 8px;cursor:pointer;">✕</button></div>'+
    '<div style="font-size:11px;color:#9ca3af;margin-bottom:8px;word-break:break-all;">'+location.href+'</div>'+
    row('Title ('+titleLen+' chars)', title||'(missing)', titleLen>=50&&titleLen<=60?'ok':(titleLen? 'warn':'bad'))+
    row('Meta description ('+descLen+')', desc||'(missing)', descLen>=140&&descLen<=160?'ok':(descLen?'warn':'bad'))+
    row('Robots', robots, /noindex/i.test(robots)?'bad':'ok')+
    row('Canonical', canon, selfCanon?'ok':(canon==='(none)'?'warn':'warn'))+
    row('H1 count / text', h1s.length+' — '+(h1s.join(' | ')||'(none)'), h1s.length===1?'ok':'warn')+
    row('Open Graph', (ogt?'title ✓ ':'title ✗ ')+(ogd?'desc ✓ ':'desc ✗ ')+(ogi?'image ✓':'image ✗'), ogt&&ogi?'ok':'warn')+
    row('Twitter card', tw||'(none)', tw?'ok':'warn')+
    row('JSON-LD blocks', String(jsonld), jsonld?'ok':'warn')+
    row('Hreflang', hreflang.length?hreflang.join(' · '):'(none)', 'ok')+
    row('Images', imgs.length+' total · '+noalt+' missing alt · '+emptyalt+' empty alt', noalt?'warn':'ok')+
    row('Links', links.length+' · '+ext+' external · '+nof+' nofollow', 'ok')+
    '<div style="margin-top:10px;font-size:11px;color:#6b7280;">Click again to dismiss. Data stays in-page — no network.</div></div>';
  function row(k,v,s){
    var c=s==='ok'?'#16a34a':s==='warn'?'#ca8a04':'#dc2626';
    return '<div style="border-top:1px solid #1f2937;padding:7px 0;"><div style="color:#93c5fd;font-size:11px;text-transform:uppercase;letter-spacing:.04em;">'+esc(k)+'</div><div style="color:#f9fafb;word-break:break-word;"><span style="display:inline-block;width:8px;height:8px;border-radius:99px;background:'+c+';margin-right:6px;"></span>'+esc(v)+'</div></div>';
  }
  function esc(s){return String(s).replace(/[&<>]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;'}[c];});}
  document.documentElement.appendChild(document.createRange().createContextualFragment(html));
  document.getElementById(ID+'-x').onclick=function(){var n=document.getElementById(ID);if(n)n.remove();};
})();
