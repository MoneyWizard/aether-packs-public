(function(){
  var md='['+(document.title||'link').replace(/[\[\]]/g,'')+']('+location.href+')';
  var html='<a href="'+location.href+'">'+document.title+'</a>';
  function done(){var n=document.createElement('div');n.style.cssText='all:initial;position:fixed;bottom:16px;left:50%;transform:translateX(-50%);z-index:2147483647;background:#0b1220;color:#86efac;font:13px ui-sans-serif,system-ui;padding:8px 14px;border-radius:999px;';n.textContent='Copied Markdown link';document.body.appendChild(n);setTimeout(function(){n.remove();},1600);}
  if(navigator.clipboard&&window.ClipboardItem){
    try{
      navigator.clipboard.write([new ClipboardItem({'text/plain':new Blob([md],{type:'text/plain'}),'text/html':new Blob([html],{type:'text/html'})})]).then(done);
      return;
    }catch(e){}
  }
  if(navigator.clipboard)navigator.clipboard.writeText(md).then(done);else prompt('Copy:',md);
})();
