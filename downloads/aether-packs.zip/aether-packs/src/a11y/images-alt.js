(function(){
  var ID='aether-a11y-img';if(document.getElementById(ID)){document.getElementById(ID).remove();document.querySelectorAll('[data-aether-ai]').forEach(function(el){el.style.outline='';el.removeAttribute('data-aether-ai');});return;}
  var imgs=Array.prototype.slice.call(document.querySelectorAll('img,svg[role="img"],[role="img"]'));
  var miss=0,dec=0;
  imgs.forEach(function(el){
    el.setAttribute('data-aether-ai','1');
    var alt=el.getAttribute('alt');
    var lab=el.getAttribute('aria-label')||el.getAttribute('aria-labelledby');
    var ok=false,note='';
    if(el.tagName==='IMG'){
      if(alt==null&&!lab){note='NO ALT';miss++;}
      else if(alt==='' ){note='decorative';dec++;ok=true;}
      else {note=(alt||lab||'').slice(0,40);ok=true;}
    }else{
      if(lab){note=String(lab).slice(0,40);ok=true;} else {note='svg/role=img unlabeled';miss++;}
    }
    el.style.outline='3px solid '+(ok?'#22c55e':'#ef4444');
    var b=document.createElement('span');b.id='';b.setAttribute('data-aether-ai','1');
    b.textContent=note;b.style.cssText='position:absolute;z-index:2147483646;background:'+(ok?'#22c55e':'#ef4444')+';color:#111;font:700 10px ui-sans-serif,system-ui;padding:1px 4px;';
    if(getComputedStyle(el).position==='static')el.style.position='relative';
    try{el.parentNode.insertBefore(b,el);}catch(e){}
  });
  var box=document.createElement('div');box.id=ID;
  box.style.cssText='all:initial;position:fixed;bottom:12px;left:12px;z-index:2147483647;background:#0b1220;color:#e5e7eb;font:12px ui-sans-serif,system-ui;padding:10px 12px;border-radius:8px;border:1px solid #1f2937;';
  box.textContent='Images/icons: '+imgs.length+' · missing name: '+miss+' · decorative: '+dec;
  document.body.appendChild(box);
})();
