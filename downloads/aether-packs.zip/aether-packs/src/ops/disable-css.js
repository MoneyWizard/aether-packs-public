(function(){
  var flag=document.documentElement.getAttribute('data-aether-css');
  var sheets=Array.prototype.slice.call(document.querySelectorAll('link[rel=stylesheet],style'));
  if(flag){
    sheets.forEach(function(n){if(n.__aetherWas)n.disabled=false;});
    document.documentElement.removeAttribute('data-aether-css');
    return;
  }
  sheets.forEach(function(n){n.__aetherWas=!n.disabled;n.disabled=true;});
  document.documentElement.setAttribute('data-aether-css','off');
})();
