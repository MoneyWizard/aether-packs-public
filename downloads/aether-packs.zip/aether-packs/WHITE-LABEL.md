# White-label & packaging guide

Use Aether Packs as a bonus asset, not a competing SaaS. The value is **speed + zero install + visible source**.

## Suggested SKUs

1. **Course bonus** — “Operator toolkit” module after the first paid lesson. Host `index.html` on your lesson platform.
2. **Membership perk** — quarterly drop: add 1–2 new bookmarklets, bump `catalog.json` version, rebuild.
3. **SaaS companion** — in-app “browser tools” page for customers who live in Chrome/Firefox all day (SEO suites, a11y platforms, QA management).
4. **Retainer kit** — zip this folder, plus a 20-minute Loom walking through the SEO and A11y packs on the client’s site.
5. **Team pack** — pin the gallery internally; require review of `src/` before adding to shared bookmark folders.

## How to brand it

- Change `product`, `tagline`, and pack names in `catalog.json`.
- Restyle CSS in `build.py` (`CSS` string) to match your brand tokens.
- Run `python3 build.py`.
- Optionally rename the root folder.

Do not claim these tools replace a full crawler, axe-core CI, or lab Lighthouse. Position them as **spot-check instruments**.

## Licensing posture (pick one and state it)

- **Members-only, no redistribution** — safest for course/SaaS bonuses.
- **Team license** — seat or domain limited.
- **Internal use + source visible** — recommended; bookmarklets are readable anyway.

## Support script (copy into your help desk)

> Drag the button onto your bookmarks bar. If the click does nothing, your browser may block `javascript:` bookmarks from this page — copy the URL and paste it into a bookmark you create yourself. Overlays: click the same tool again to clear. Refresh always resets the page.

## Roadmap ideas (keep packs specialized)

- SEO: hreflang matrix table, rendered vs raw title compare
- A11y: approximate contrast pairs on selected text
- QA: HAR-lite resource waterfall, same-origin broken-link HEAD probe
- CMS variants: Webflow / WordPress admin field fillers
