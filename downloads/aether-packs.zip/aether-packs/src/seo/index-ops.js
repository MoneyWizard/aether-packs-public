(function(){
  var host=location.hostname;
  var url=encodeURIComponent(location.href);
  var q=encodeURIComponent(location.href.replace(/\/$/,''));
  var tools=[
    ['Google site:', 'https://www.google.com/search?q=site:'+host],
    ['Indexed URL', 'https://www.google.com/search?q=site:'+q],
    ['Cache', 'https://webcache.googleusercontent.com/search?q=cache:'+url],
    ['site: + intitle', 'https://www.google.com/search?q=site:'+host+'+intitle:'+encodeURIComponent(document.title.split('|')[0].trim())],
    ['Rich results test', 'https://search.google.com/test/rich-results?url='+url],
    ['URL Inspection (GSC)', 'https://search.google.com/search-console/inspect?resource_id='+encodeURIComponent(location.origin)+'&id='+url],
    ['PageSpeed', 'https://pagespeed.web.dev/analysis?url='+url],
    ['Mobile-Friendly', 'https://search.google.com/test/mobile-friendly?url='+url],
    ['W3C HTML', 'https://validator.w3.org/nu/?doc='+url],
    ['Structured Data (schema.org val.)', 'https://validator.schema.org/#url='+url],
    ['Wayback', 'https://web.archive.org/web/*/'+location.href],
    ['Similarweb', 'https://www.similarweb.com/website/'+host+'/']
  ];
  var ID='aether-ops';var old=document.getElementById(ID);if(old){old.remove();return;}
  var box=document.createElement('div');box.id=ID;
  box.style.cssText='all:initial;position:fixed;top:12px;right:12px;z-index:2147483647;width:300px;background:#0b1220;color:#e5e7eb;font:13px/1.5 ui-sans-serif,system-ui;padding:12px;border-radius:10px;border:1px solid #1f2937;';
  box.innerHTML='<strong style="color:#93c5fd;">SEO operators</strong><button id="'+ID+'x" style="float:right;background:#1f2937;color:#fff;border:0;border-radius:4px;cursor:pointer;">✕</button><div style="margin-top:8px;">'+
    tools.map(function(t){return '<a href="'+t[1]+'" target="_blank" rel="noopener" style="display:block;color:#93c5fd;padding:4px 0;text-decoration:none;border-bottom:1px solid #1f2937;">'+t[0]+' ↗</a>';}).join('')+'</div>';
  document.body.appendChild(box);
  document.getElementById(ID+'x').onclick=function(){box.remove();};
})();
