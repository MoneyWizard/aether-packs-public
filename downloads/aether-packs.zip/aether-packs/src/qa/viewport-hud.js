(function(){
  var ID='aether-vp';
  if(document.getElementById(ID)){document.getElementById(ID).remove();window.removeEventListener('resize',window.__aetherVp);return;}
  var dpr=window.devicePixelRatio||1;
  var box=document.createElement('div');box.id=ID;
  box.style.cssText='all:initial;position:fixed;top:8px;left:8px;z-index:2147483647;background:#0b1220;color:#e5e7eb;font:12px/1.4 ui-monospace,ui-sans-serif,system-ui;padding:10px 12px;border-radius:10px;border:1px solid #1f2937;min-width:200px;';
  function paint(){
    box.innerHTML='<b style="color:#93c5fd;">Viewport HUD</b><div>'+innerW()+' × '+window.innerHeight+' css px</div><div>DPR '+dpr+' · screen '+screen.width+'×'+screen.height+'</div>'+
      '<div style="margin-top:6px;">'+btns()+'</div>';
    Array.prototype.slice.call(box.querySelectorAll('[data-w]')).forEach(function(b){
      b.onclick=function(){alert('Resize the window / DevTools device mode to '+b.getAttribute('data-w')+'×'+b.getAttribute('data-h')+' (bookmarklets cannot resize the browser chrome).');};
    });
  }
  function innerW(){return window.innerWidth;}
  function btns(){
    return [['320','568','iP SE'],['375','812','iP X'],['390','844','iP 14'],['768','1024','iPad'],['1280','800','Laptop'],['1440','900','Desktop']].map(function(p){
      return '<button data-w="'+p[0]+'" data-h="'+p[1]+'" style="margin:0 4px 4px 0;background:#1f2937;color:#fff;border:0;border-radius:4px;padding:3px 6px;cursor:pointer;font:11px ui-sans-serif,system-ui;">'+p[2]+'</button>';
    }).join('');
  }
  document.body.appendChild(box);paint();
  window.__aetherVp=paint;window.addEventListener('resize',paint);
})();
