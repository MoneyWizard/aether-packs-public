(function(){
  var ID='aether-store';var old=document.getElementById(ID);if(old){old.remove();return;}
  function dump(store){
    var out=[];
    try{for(var i=0;i<store.length;i++){var k=store.key(i);out.push(k+' = '+String(store.getItem(k)).slice(0,180));}}catch(e){out.push('(blocked) '+e.message);}
    return out;
  }
  var cookies=(document.cookie||'').split(/;\s/).filter(Boolean);
  var box=document.createElement('div');box.id=ID;
  box.style.cssText='all:initial;position:fixed;top:12px;right:12px;z-index:2147483647;width:420px;max-height:88vh;overflow:auto;background:#0b1220;color:#e5e7eb;font:12px/1.4 ui-monospace,ui-sans-serif,system-ui;padding:12px;border-radius:10px;border:1px solid #1f2937;white-space:pre-wrap;word-break:break-word;';
  box.innerHTML='<strong style="color:#93c5fd;font-family:ui-sans-serif,system-ui;">Storage inspector</strong> <span id="'+ID+'x" style="float:right;cursor:pointer;">✕</span>'+
    '\n\n— cookies ('+cookies.length+') —\n'+esc(cookies.join('\n')||'(none)')+
    '\n\n— localStorage ('+safeLen(localStorage)+') —\n'+esc(dump(localStorage).join('\n')||'(empty)')+
    '\n\n— sessionStorage ('+safeLen(sessionStorage)+') —\n'+esc(dump(sessionStorage).join('\n')||'(empty)');
  function safeLen(s){try{return s.length;}catch(e){return '?';}}
  function esc(s){return String(s).replace(/[&<>]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;'}[c];});}
  document.body.appendChild(box);
  document.getElementById(ID+'x').onclick=function(){box.remove();};
})();
