(function(){
  if(window.__aetherPick){window.__aetherPick.off();return;}
  var tip=document.createElement('div');
  tip.style.cssText='all:initial;position:fixed;z-index:2147483647;background:#0b1220;color:#e5e7eb;font:11px/1.35 ui-monospace,ui-sans-serif,system-ui;padding:6px 8px;border-radius:6px;pointer-events:none;max-width:420px;border:1px solid #38bdf8;';
  document.body.appendChild(tip);
  var last;
  function cssPath(el){
    if(el.id)return '#'+CSS.escape(el.id);
    var parts=[];
    while(el&&el.nodeType===1&&parts.length<5){
      var s=el.tagName.toLowerCase();
      if(el.className&&typeof el.className==='string'){var c=el.className.trim().split(/\s+/)[0];if(c)s+='.'+CSS.escape(c);}
      var p=el.parentNode;if(p){var same=[].filter.call(p.children,function(n){return n.tagName===el.tagName;});if(same.length>1)s+=':nth-of-type('+([].indexOf.call(same,el)+1)+')';}
      parts.unshift(s);el=el.parentElement;
    }
    return parts.join(' > ');
  }
  function xpath(el){
    if(el.id)return '//*[@id="'+el.id+'"]';
    var segs=[];
    for(;el&&el.nodeType===1;el=el.parentNode){
      var i=1,sib=el.previousSibling;
      for(;sib;sib=sib.previousSibling)if(sib.nodeType===1&&sib.tagName===el.tagName)i++;
      segs.unshift(el.tagName.toLowerCase()+'['+i+']');
    }
    return '/'+segs.join('/');
  }
  function over(e){
    if(last)last.style.outline='';
    last=e.target;last.style.outline='2px solid #38bdf8';
    tip.textContent=cssPath(e.target);
    tip.style.left=Math.min(e.clientX+12,innerWidth-240)+'px';
    tip.style.top=Math.min(e.clientY+12,innerHeight-40)+'px';
  }
  function click(e){
    e.preventDefault();e.stopPropagation();
    var el=e.target;
    var text='CSS: '+cssPath(el)+'\nXPath: '+xpath(el)+'\nText: '+((el.innerText||'').trim().slice(0,120));
    if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(text);
    alert('Copied selector bundle:\n\n'+text+'\n\nClick the bookmarklet again to exit picker.');
  }
  function off(){
    document.removeEventListener('mouseover',over,true);
    document.removeEventListener('click',click,true);
    if(last)last.style.outline='';
    tip.remove();window.__aetherPick=null;
  }
  document.addEventListener('mouseover',over,true);
  document.addEventListener('click',click,true);
  window.__aetherPick={off:off};
})();
