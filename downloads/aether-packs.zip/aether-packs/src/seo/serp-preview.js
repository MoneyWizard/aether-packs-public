(function(){
  var ID='aether-serp';var old=document.getElementById(ID);if(old){old.remove();return;}
  function m(sel,attr){var e=document.querySelector(sel);return e?((attr?e.getAttribute(attr):e.content)||e.textContent||'').trim():'';}
  var title=document.title||'(no title)';
  var desc=m('meta[name="description"]')||'(no meta description)';
  var url=location.host+location.pathname;
  var tOk=title.length>=50&&title.length<=60;
  var dOk=desc.length>=140&&desc.length<=160;
  var box=document.createElement('div');box.id=ID;
  box.style.cssText='all:initial;position:fixed;top:16px;left:50%;transform:translateX(-50%);z-index:2147483647;width:600px;max-width:96vw;background:#fff;color:#202124;font:14px/1.58 arial,sans-serif;padding:16px 18px 18px;border-radius:12px;box-shadow:0 16px 50px rgba(0,0,0,.28);';
  box.innerHTML='<div style="font:12px ui-sans-serif,system-ui;color:#5f6368;margin-bottom:8px;display:flex;justify-content:space-between;">Aether SERP preview · title '+title.length+' / desc '+desc.length+' chars <span id="'+ID+'x" style="cursor:pointer;color:#1a0dab;">close</span></div>'+
    '<div style="color:#202124;font-size:14px;">'+esc(url)+'</div>'+
    '<div style="color:#1a0dab;font-size:20px;line-height:1.3;margin:2px 0 4px;cursor:default;">'+esc(title)+'</div>'+
    '<div style="color:#4d5156;">'+esc(desc)+'</div>'+
    '<div style="margin-top:10px;font:12px ui-sans-serif,system-ui;color:#5f6368;">Title target 50–60: '+(tOk?'✓':'△')+' · Description target 140–160: '+(dOk?'✓':'△')+'</div>';
  function esc(s){return String(s).replace(/[&<>]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;'}[c];});}
  document.body.appendChild(box);
  document.getElementById(ID+'x').onclick=function(){box.remove();};
})();
