(function(){
  var ID='aether-out';
  var s=document.getElementById(ID);
  if(s){s.remove();return;}
  s=document.createElement('style');s.id=ID;
  s.textContent='* { outline:1px solid rgba(244,63,94,.35) !important; } img{outline-color:rgba(56,189,248,.6)!important;} a{outline-color:rgba(34,197,94,.6)!important;} button,input,select,textarea{outline-color:rgba(250,204,21,.7)!important;}';
  document.head.appendChild(s);
})();
