(function(){
  var ID='aether-img';
  var old=document.getElementById(ID);if(old){old.remove();return;}
  var imgs=Array.prototype.slice.call(document.images);
  var rows=imgs.map(function(img,i){
    var alt=img.getAttribute('alt');
    var issue=alt==null?'MISSING ALT':alt===''?'EMPTY ALT (ok if decorative)':'';
    if(!img.currentSrc&&!img.src)issue+=(issue?' · ':'')+'NO SRC';
    var w=img.naturalWidth||0,h=img.naturalHeight||0;
    var dw=img.clientWidth,dh=img.clientHeight;
    var over=w&&dw&&w>dw*2?'OVERSIZED':'';
    img.style.outline=issue&&issue.indexOf('MISSING')===0?'3px solid #ef4444':issue?'3px solid #eab308':'3px solid #22c55e';
    return {i:i+1,alt:alt==null?'∅':alt.slice(0,80),dim:w+'×'+h+' (display '+dw+'×'+dh+')',lazy:img.loading||'',src:(img.currentSrc||img.src||'').slice(-60),issue:issue||over||'ok'};
  });
  var miss=rows.filter(function(r){return r.issue.indexOf('MISSING')===0;}).length;
  var box=document.createElement('div');box.id=ID;
  box.style.cssText='all:initial;position:fixed;top:12px;right:12px;z-index:2147483647;width:460px;max-height:88vh;overflow:auto;background:#0b1220;color:#e5e7eb;font:12px/1.4 ui-sans-serif,system-ui;padding:12px;border-radius:10px;border:1px solid #1f2937;';
  var html='<strong style="color:#93c5fd;">Image audit</strong> · '+imgs.length+' images · '+miss+' missing alt<button id="'+ID+'x" style="float:right;background:#1f2937;color:#fff;border:0;border-radius:4px;cursor:pointer;">✕</button><table style="width:100%;border-collapse:collapse;margin-top:8px;color:#d1d5db;">';
  rows.forEach(function(r){
    html+='<tr style="border-top:1px solid #1f2937;vertical-align:top;"><td style="padding:4px 4px 4px 0;color:#93c5fd;">'+r.i+'</td><td style="padding:4px;">'+esc(r.alt)+'<div style="color:#9ca3af;">'+esc(r.dim)+' · '+esc(r.src)+'</div><div style="color:'+(r.issue==='ok'?'#22c55e':'#f59e0b')+';">'+esc(r.issue)+'</div></td></tr>';
  });
  box.innerHTML=html+'</table>';
  function esc(s){return String(s).replace(/[&<>]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;'}[c];});}
  document.body.appendChild(box);
  document.getElementById(ID+'x').onclick=function(){box.remove();imgs.forEach(function(i){i.style.outline='';});};
})();
