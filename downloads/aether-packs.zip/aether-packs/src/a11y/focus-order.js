(function(){
  var ID='aether-focus';
  if(window.__aetherFocus){window.__aetherFocus.off();return;}
  var style=document.createElement('style');style.id=ID+'s';
  style.textContent='*:focus{outline:3px solid #facc15 !important;outline-offset:3px !important;} .aether-fn{position:absolute;z-index:2147483646;background:#facc15;color:#111;font:700 10px ui-sans-serif,system-ui;padding:1px 4px;border-radius:3px;pointer-events:none;}';
  document.head.appendChild(style);
  var sels='a[href],button,input,select,textarea,summary,[tabindex]:not([tabindex="-1"])';
  var els=Array.prototype.slice.call(document.querySelectorAll(sels)).filter(function(el){
    if(el.disabled)return false;
    var r=el.getBoundingClientRect();
    return r.width||r.height||el.tagName==='INPUT';
  });
  els.forEach(function(el,i){
    var n=document.createElement('span');n.className='aether-fn';n.textContent=String(i+1);
    if(getComputedStyle(el).position==='static')el.style.position='relative';
    el.insertBefore(n,el.firstChild);
  });
  var hud=document.createElement('div');hud.id=ID;
  hud.style.cssText='all:initial;position:fixed;bottom:12px;right:12px;z-index:2147483647;background:#0b1220;color:#fde68a;font:12px ui-sans-serif,system-ui;padding:10px 12px;border-radius:8px;border:1px solid #1f2937;';
  hud.textContent='Focus order · '+els.length+' tab stops · Tab to walk · click tool again to clear';
  document.body.appendChild(hud);
  window.__aetherFocus={off:function(){
    document.querySelectorAll('.aether-fn').forEach(function(n){n.remove();});
    var s=document.getElementById(ID+'s');if(s)s.remove();
    var h=document.getElementById(ID);if(h)h.remove();
    window.__aetherFocus=null;
  }};
})();
