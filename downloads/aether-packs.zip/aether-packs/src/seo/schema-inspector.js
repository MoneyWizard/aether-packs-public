(function(){
  var ID='aether-schema';var old=document.getElementById(ID);if(old){old.remove();return;}
  var blocks=Array.prototype.slice.call(document.querySelectorAll('script[type="application/ld+json"]'));
  var parsed=[];
  blocks.forEach(function(s,i){
    try{
      var data=JSON.parse(s.textContent);
      var arr=Array.isArray(data)?data:data['@graph']?data['@graph']:[data];
      arr.forEach(function(n){parsed.push({i:i+1,type:n['@type']||'(no @type)',name:n.name||n.headline||n.url||''});});
    }catch(e){parsed.push({i:i+1,type:'INVALID JSON',name:String(e.message)}); }
  });
  var micros=Array.prototype.slice.call(document.querySelectorAll('[itemtype]')).map(function(el){return el.getAttribute('itemtype');});
  var box=document.createElement('div');box.id=ID;
  box.style.cssText='all:initial;position:fixed;top:12px;right:12px;z-index:2147483647;width:400px;max-height:88vh;overflow:auto;background:#0b1220;color:#e5e7eb;font:12px/1.45 ui-sans-serif,system-ui;padding:12px;border-radius:10px;border:1px solid #1f2937;';
  box.innerHTML='<strong style="color:#93c5fd;">Schema inspector</strong><button id="'+ID+'x" style="float:right;background:#1f2937;color:#fff;border:0;border-radius:4px;cursor:pointer;">✕</button>'+
    '<div style="margin:8px 0;color:#9ca3af;">JSON-LD scripts: '+blocks.length+' · nodes: '+parsed.length+' · microdata itemtypes: '+micros.length+'</div>'+
    parsed.map(function(p){return '<div style="border-top:1px solid #1f2937;padding:6px 0;"><span style="color:#93c5fd;">#'+p.i+'</span> <b>'+esc(String(p.type))+'</b><div style="color:#d1d5db;">'+esc(String(p.name))+'</div></div>';}).join('')+
    (micros.length?'<div style="margin-top:8px;color:#a7f3d0;">Microdata: '+esc(micros.join(', '))+'</div>':'');
  function esc(s){return String(s).replace(/[&<>]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;'}[c];});}
  document.body.appendChild(box);
  document.getElementById(ID+'x').onclick=function(){box.remove();};
})();
