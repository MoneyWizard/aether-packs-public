# Aether Packs

Zero-install bookmarklet bundles for **SEO**, **accessibility**, **QA / test automation**, and **ops**.

Built to ship as a **premium bonus** with courses, retainers, memberships, or SaaS plans: host `index.html` in a members area and let subscribers drag tools onto the bookmarks bar.

## What’s in the box

| Pack | Tools | Job |
| --- | --- | --- |
| SEO Operator | 7 | On-page X-ray, headings, links, images, schema, SERP chrome, Google/PSI/GSC operators |
| A11y Sentinel | 8 | Headings, landmarks, labels, image names, focus order, 1.4.12 spacing, lang/skip, grayscale |
| QA Forge | 8 | Smart form fill (framework events), viewport HUD, outline debug, passwords, storage, perf, CWV, selector picker |
| Ops & Content | 5 | Clean URL, Markdown copy, content stats, CSV link export, CSS off |

**28 tools.** Each source file is plain JavaScript in `src/`.

## Install for end users

1. Open `index.html` (local file or your gated URL).
2. Show the bookmarks bar.
3. Drag a colored button onto the bar.
4. Visit any page and click the bookmark.

Mobile: use **Copy javascript: URL**, create a bookmark, paste into the URL field.

## Rebuild the gallery

```bash
python3 build.py
```

## Product notes

- No accounts, no background scripts, no store listing review.
- Most tools are same-origin DOM only. `Index Operators` opens public third-party URLs. `Export Links CSV` downloads locally.
- Toggle pattern: run the same bookmarklet again to remove overlays.
- Bookmarklets run with the privileges of the current page. Document that in your terms.

See `WHITE-LABEL.md` for packaging this as a bonus SKU.
